# Blank-HTML
A basic web site structure to begin a HTML project.
