
/*Add any JavaScript code you like here, for example any JQuery event handlers.

	$('...').on('event_name', function (event) {
	
	});
*/
